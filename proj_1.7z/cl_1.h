#ifndef CL_1_H
#define CL_1_H

#include "cl_base.h"

class cl_1 : public cl_base
{
public:
    cl_1 ( );
};

#endif // CL_1_H
