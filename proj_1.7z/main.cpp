#include <iostream>

#include "cl_application.h"

using namespace std;

int main()
{
    cl_application  ob_application;
    ob_application.bild_tree_objects();

    return ob_application.exec_app ();
}
