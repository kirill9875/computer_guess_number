#include "cl_application.h"

cl_application :: cl_application()
{
    set_object_name ( "root" );
    set_state       ( 1 );
}
void cl_application :: bild_tree_objects ( )
{
    ob_1.set_object_name ( "ob_1" );
    ob_1.set_parent      ( this   );
    ob_3.set_object_name ( "ob_3" );
    ob_3.set_parent      ( this   );

    ob_2.set_object_name ( "ob_2" );
    ob_2.set_parent      ( & ob_1 );
}
int cl_application :: exec_app ( )
{
    show_object_state ( );
    return 0;
}
void cl_application :: show_object_state ( )
{
    show_state_next ( this );
}
void cl_application :: show_state_next ( cl_base * ob_parent )
{
    if ( ob_parent -> get_state ( ) == 1 ) {
        cout << "The object " << ob_parent -> get_object_name () << " is ready" << endl;
    }
    else {
        cout << "The object " << ob_parent -> get_object_name () << " is not ready" << endl;
    }
    if ( ob_parent -> children.size ( ) == 0 ) return;

    ob_parent -> it_child = ob_parent -> children.begin ( );

    while ( ob_parent -> it_child != ob_parent -> children.end ( ) ) {
        show_state_next ( ( * ( ob_parent -> it_child ) ) );
        ob_parent -> it_child ++;
    }
}
