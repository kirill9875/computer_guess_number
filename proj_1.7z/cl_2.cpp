#include "cl_2.h"

cl_2 :: cl_2 ( )
{
    set_state ( 1 );
}
