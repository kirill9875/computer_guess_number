#ifndef CL_2_H
#define CL_2_H

#include "cl_base.h"

class cl_2 : public cl_base
{
public:
    cl_2 ( );
};

#endif // CL_2_H
