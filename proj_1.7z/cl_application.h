#ifndef CL_APPLICATION_H
#define CL_APPLICATION_H
#include "cl_1.h"
#include "cl_2.h"

class cl_application : public cl_base
{
public:
    cl_application ( );
    void bild_tree_objects ( );
    int  exec_app          ( );
    void show_object_state ( );

private:
    void show_state_next ( cl_base * ob_parent );
    cl_1  ob_1;
    cl_2  ob_2;
    cl_1  ob_3;
};

#endif // CL_APPLICATION_H
