#include "cl_1.h"

cl_1::cl_1()
{
    set_state ( 1 );
}
